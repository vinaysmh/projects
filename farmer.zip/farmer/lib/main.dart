import 'package:farmer/screens/wrapper.dart';
import 'package:farmer/services/auth.dart';
import 'package:splashscreen/splashscreen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:farmer/models/user.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  double imageSize; //variable to store and manipulate image size on change in orientation
  @override
  Widget build(BuildContext context) {

    double screenHeight = MediaQuery.of(context).size.height; //measure the height of device screen
    //Detect Device orientation and change image size to fit screen in landscape mode
    if (MediaQuery.of(context).orientation == Orientation.landscape) {
      imageSize = screenHeight * 0.15; //15% of screen height
    }
    //Detect Device orientation and change image size to fit screen in portrait mode
    else if (MediaQuery.of(context).orientation == Orientation.portrait) {
      imageSize = screenHeight * 0.20; //20% of screen height
    }
    return Container(
      child: SplashScreen(
        loaderColor: Colors.black,
        seconds: 5,
        navigateAfterSeconds:
        AfterSplash(), //widget to go when the duration is over for splashscreen
        //image: new Image.asset('assets/logo.png'),
        loadingText: Text('Welcome User'),
        //photoSize: imageSize,
      ),
    );

  }
}

class AfterSplash extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamProvider<User>.value(
      value: AuthService().user,
      child: MaterialApp(
        home: Wrapper(),
      ),
    );
  }
}
