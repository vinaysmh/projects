import 'package:farmer/models/user.dart';
import 'package:farmer/services/database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
class AuthService {

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final CollectionReference db = Firestore.instance.collection('users');
  final GoogleSignIn googleSignIn = GoogleSignIn(scopes: ['email'],);
  String date = DateTime.now().toIso8601String();
  // create user obj based on firebase user
  User _userFromFirebaseUser(FirebaseUser user) {
    return user != null ? User(uid: user.uid) : null;
  }
  // auth change user stream
  Stream<User> get user {
    return _auth.onAuthStateChanged
      .map(_userFromFirebaseUser);
  }
//Google Signup/login
  //Auth with Google--perfect
  Future<void> googleSignUp() async {
    try {
      final GoogleSignInAccount googleUser = await googleSignIn.signIn();
      final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
      final AuthCredential credential = GoogleAuthProvider.getCredential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );
      final FirebaseUser user = (await _auth.signInWithCredential(credential)).user;
      await db.document(user.uid).get().then((value){
        if(value.data==null || !value.exists){
         DatabaseService(uid: user.uid).createUserData(user.email, user.phoneNumber, date,'google');
        }
      });
      return _userFromFirebaseUser(user);
    }catch (e) {
      print(e.message);
    }
  }

  // sign in anon --don't implement this --just for tutorial
  Future signInAnonymously() async {
    try {
      AuthResult result = await _auth.signInAnonymously();
      FirebaseUser user = result.user;
      return _userFromFirebaseUser(user);
    } catch (e) {
      print(e.toString());
      return null;
    }
  }

  // sign in with email and password
  Future signInWithEmailAndPassword(String email,password) async {
    try {
      AuthResult result = await _auth.signInWithEmailAndPassword(email: email, password: password);
      FirebaseUser user = result.user;
      //check and send verification email
      var verified = user.isEmailVerified.toString();
      if(verified == 'false'){
        user.sendEmailVerification();
      }
      return user;
    } catch (error) {
      print(error.toString());
      return null;
    } 
  }

  // register with email and password
  Future registerWithEmailAndPassword(String email,password,phone) async {
    try {
      AuthResult result = await _auth.createUserWithEmailAndPassword(email: email, password: password);
      FirebaseUser user = result.user;
      //create userdata in dB
      if(user!=null){
        DatabaseService(uid: user.uid).createUserData(email, phone, date,'email');
      }
      //send email verification
      user.sendEmailVerification();
      return _userFromFirebaseUser(user);
    } catch (error) {
      print(error.toString());
      return null;
    } 
  }

  // sign out
  Future signOut() async {
    try {
      return await _auth.signOut();
    } catch (error) {
      print(error.toString());
      return null;
    }
  }
  //password reset
Future passwordReset(String email)async{
  try {
    return await _auth.sendPasswordResetEmail(email: email);
  } catch (error) {
    print(error.toString());
    return null;
  }
}

}