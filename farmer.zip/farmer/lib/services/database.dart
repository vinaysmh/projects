import 'package:farmer/models/user.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class DatabaseService {
  final String uid;
  DatabaseService({ this.uid });
  // collection reference
  final CollectionReference colRef = Firestore.instance.collection('users');
  //create user data
  Future createUserData(String email,phone,date,agent) async{//create initial user's data in firestore
    return await colRef.document(uid).setData({
      'phone' : phone,
      'role':'farmer',
      'email' : email,
      'authBy' : agent,
      'date' : date,
    });
  }//Future
  // user data from snapshots
  UserData _userDataFromSnapshot(DocumentSnapshot snapshot) {
    return UserData(
      uid: uid,
      role: snapshot.data['date'],
      date: snapshot.data['role'],
      phone: snapshot.data['phone'],
      email: snapshot.data['email'],
    );
  }
  // get user doc stream
  Stream<UserData> get userData {
    return colRef.document(uid).snapshots()
      .map(_userDataFromSnapshot);
  }

}