import 'package:farmer/services/auth.dart';
import 'package:farmer/services/database.dart';
import 'package:farmer/shared/constants.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:farmer/models/user.dart';

class Home extends StatelessWidget {
  final AuthService _auth = AuthService();
  @override
  Widget build(BuildContext context) {
    final user = Provider.of<User>(context);
    return StreamBuilder<UserData>(
        stream: DatabaseService(uid: user.uid).userData,
          builder: (context, snapshot) {
        if(snapshot.hasData){
        UserData a = snapshot.data;
        return Scaffold(
          backgroundColor: Colors.brown[50],
          appBar: AppBar(
            title: Text('Logged IN'),
            backgroundColor: Colors.brown[400],
            elevation: 0.0,
            actions: <Widget>[
              FlatButton.icon(
                icon: Icon(Icons.person),
                label: Text('logout'),
                onPressed: () async {
                  await _auth.signOut();
                },
              ),
              FlatButton.icon(
                icon: Icon(Icons.settings),
                label: Text('settings'),
                onPressed: (){},
              )
            ],
          ),
          body: Container(
            height: MediaQuery.of(context).size.height,
            alignment: Alignment.center,
            child: SingleChildScrollView(
              physics: AlwaysScrollableScrollPhysics(),
              child: Card(
                shape: cShape,
                margin: EdgeInsets.fromLTRB(10, 40, 10, 40),
                child: ListTile(
                  title: Text(a.email +'\n'+ a.phone),
                  subtitle: Text(a.role + '\n' + a.date),
                ),
              ),
            )
          ),
        );
        }else{
          return Loading();
        }
      }
    );
  }
}