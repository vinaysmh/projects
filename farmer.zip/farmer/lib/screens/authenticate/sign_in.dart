import 'package:farmer/services/auth.dart';
import 'package:farmer/shared/constants.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SignIn extends StatefulWidget {
  final Function toggleView;
  SignIn({ this.toggleView });
  @override
  _SignInState createState() => _SignInState();
}

class _SignInState extends State<SignIn> {
  final AuthService _auth = AuthService();
  final _formKey = GlobalKey<FormState>();//for login form
  final _reset = GlobalKey<FormState>();//for password reset form
  String error = '';
  bool loading = false;
  // text field state
  String email = '';
  String password = '';
  List<String> roles = ['Farmer','DOA Officer','Farm Science Expert','Weather Station Co-ordinator','Ground Team'];
  String selectedRole;
  //TODO:implement roles use during login
  @override
  Widget build(BuildContext context) {
    return loading ? Loading() : Scaffold(
      backgroundColor: Colors.brown[100],
      appBar: AppBar(
        backgroundColor: Colors.brown[400],
        elevation: 0.0,
        title: FittedBox(fit: BoxFit.scaleDown,child: Text('Sign in to DOA Portal')),
        actions: <Widget>[
          FlatButton.icon(
            icon: Icon(Icons.person),
            label: Text('Register'),
            onPressed: () => widget.toggleView(),
          ),
        ],
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        alignment: Alignment.center,
        child: SingleChildScrollView(
          physics: AlwaysScrollableScrollPhysics(),
          child: Card(
            margin: EdgeInsets.fromLTRB(10, 40, 10, 40),
            shape: cShape,
            child: Form(
              key: _formKey,
              child: Column(
                children: <Widget>[
                  ListTile(
                      title: DropdownButtonFormField(
                        validator: (value) => value == null ? 'Required' : null,
                        isExpanded: true,hint: Text('Select Role *'),
                        items: roles.map((val) {
                          return DropdownMenuItem(
                            value: val,
                            child: Text(val,),
                          );
                        }).toList(),
                        value: selectedRole,
                        onChanged: (value) {
                          setState(() {
                            selectedRole = value;
                          });
                        },
                      )),
                  ListTile(
                    title: TextFormField(
                      decoration: new InputDecoration(
                          labelText: 'Email'
                      ),
                      validator: (val) => val.isEmpty ? 'Enter an email' : null,
                      onChanged: (val) {
                        setState(() => email = val);
                      },
                    ),
                    subtitle:TextFormField(
                      obscureText: true,
                      decoration: new InputDecoration(
                          labelText: 'Password'
                      ),
                      validator: (val) => val.length < 6 ? 'Enter a password 6+ chars long' : null,
                      onChanged: (val) {
                        setState(() => password = val);
                      },
                    ) ,
                  ),
                  SizedBox(height: 8.0),
                  FlatButton(
                    child: Container(child: Text('Forgot Password ?'),alignment: Alignment.bottomRight,),
                    onPressed: showAlertDialog(context),
                  ),
                  SizedBox(height: 20.0),
                  ListTile(
                    title: RaisedButton(
                        color: Colors.pink[400],
                        child: Text(
                          'Sign In with Email',
                          style: TextStyle(color: Colors.white),
                        ),
                        onPressed: () async {
                          if(_formKey.currentState.validate()){
                            setState(() => loading = true);
                            dynamic result = await _auth.signInWithEmailAndPassword(email, password);
                            if(result == null) {
                              setState(() {
                                loading = false;
                                error = 'Could not sign in with those credentials';
                              });
                            }
                          }
                        }
                    ),
                    subtitle: RaisedButton(
                        color: Colors.pink[400],
                        child: Text(
                          'Sign In with Google',
                          style: TextStyle(color: Colors.white),
                        ),
                        onPressed: () async {
                          _auth.googleSignUp();
                        }
                    ),
                  ),
                  SizedBox(height: 12.0),
                  Text(
                    error,
                    style: TextStyle(color: Colors.red, fontSize: 14.0),
                  ),
                ],
              ),
            ),
          ),
        )
      ),
    );
  }
  showAlertDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Form(
          key: _reset,
          child: Card(
            shape: cShape,
            child: AlertDialog(
              titlePadding: EdgeInsets.all(15),
              content: Flexible(
                child: Text('If you had an account with that email, you would receive an email with further instructions to reset password '
                  ,textAlign: TextAlign.center,
                ),
              ),
              title: ListTile(
                title: Text('Password Recovery',textAlign: TextAlign.center,),
                subtitle: TextFormField(
                  decoration: new InputDecoration(
                      labelText: 'Registered Email'
                  ),
                  keyboardType: TextInputType.emailAddress,
                  validator: (val) => val.isEmpty ? 'Enter an email' : null,
                  onChanged: (val) {
                    setState(() => email = val);
                  },
                ),
              ),
              actions: <Widget>[
                ListTile(
                  title: RaisedButton(
                    onPressed: (){
                      if(_formKey.currentState.validate()){
                        _auth.passwordReset(email);
                        Navigator.of(context).pop();
                      }
                    },
                    child: Text('Reset Password'),
                  ),
                ),
                RaisedButton.icon(
                  onPressed: (){
                    Navigator.of(context).pop();
                  },
                  label: Text(''),
                  icon: Icon(Icons.close),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}