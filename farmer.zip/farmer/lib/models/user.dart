class User {
  final String uid;
  User({ this.uid });
}

class UserData {
  final String uid;
  final String role;
  final String date;
  final String email;
  final String phone;
  UserData({ this.uid,this.role, this.date,this.phone,this.email });

}